# Spring-Boot-Payment-Gateway

A simple paypal payment integration using spring boot. 

![demo](https://github.com/Nuralam51/Spring-Boot-Payment-Gateway/blob/e7b0f175ae2f9385e8b6fed61ae5f1e12fccc315/src/main/resources/static/demo.png)
