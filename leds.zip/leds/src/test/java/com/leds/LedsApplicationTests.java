package com.leds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LedsApplicationTests {

	@Test
	void contextLoads() {
	}

}
