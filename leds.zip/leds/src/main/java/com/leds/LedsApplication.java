package com.leds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LedsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LedsApplication.class, args);
	}

}
