package com.smsservice.smaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmaappApplicationTests {

	@Test
	void contextLoads() {
	}

}
